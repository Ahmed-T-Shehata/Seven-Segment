/*
 * Seven_Seg.h
 *
 * Created: 11/18/2022 1:02:27 PM
 *  Author: safifi
 */ 


#ifndef SEVEN_SEG_H_
#define SEVEN_SEG_H_

#include "std_macros.h"

void seven_seg_init(void);
void seven_seg_write(uint8_t num, uint8_t ss_num);



#endif /* SEVEN_SEG_H_ */